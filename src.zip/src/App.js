import logo from './logo.svg';
import './App.css';
import { New } from './New';

function App() {
  return (
    <div className="App">
     <New/>
    </div>
  );
}

export default App;
