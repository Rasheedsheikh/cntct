import React from 'react'

export const New = () => {
  return (
    <div>
<nav style={{backgroundColor:"black", display:"flex",gap:"20px"}}>
    <div>
    <p style={{color:"white"}}>PRICE AND AVAILABILITY</p>
    </div>

   <div style={{display:"flex",marginLeft:"50px"}}>
       <input style={{width:"700px",height:"75%",marginTop:"2px",position:"relative",border:"none"}} type="number" placeholder="Type or Paste material number by comma" />
       <input style={{height:"5%",marginTop:"7px",position:"absolute",marginLeft:"500px"}} type="date" placeholder="Effective Date"  />
       & nbsp
   </div>
   <div  style={{display:"flex",marginLeft:"50px"}}>
       <input type="file" placeholder='upload file'/>
   </div>

</nav>

<div>
<table>
  <tr>
    <th>Material Number</th>
    <th>Brand</th>
    <th>Quantity</th>
    <th>In Stock</th>
    <th>Description</th>
    <th>Price</th>
  </tr>
  <tr></tr>
  <tr></tr>
</table>
</div>

    </div>



  )
}
